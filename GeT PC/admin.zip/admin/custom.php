<?php
    session_start();
?>
<!DOCTYPE html>
<html>

<head>
  <title>Add Custom Builds</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Kiwi+Maru:wght@300&display=swap" rel="stylesheet">


</head>

<body style="background: rgb(211, 80, 80);
  background: linear-gradient(90deg, rgb(19, 18, 95) 0%, rgb(21, 155, 93) 0%, rgb(70, 172, 192) 100%);">

<!-- PHP START -->
<?php
  include "navbar.php";
  include "../dbconnect.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	$lpname = $_POST['lpname'];
	$processor = $_POST['processor'];
	$ram = $_POST['ram'];
	$storage = $_POST['storage'];
	$usage = $_POST['usage'];
	$price = $_POST['price'];
	$link = $_POST['link'];
  $g_card = $_POST['g_card'];
	$motherboard = $_POST['motherboard'];
    $cabinet = $_POST['cabinet'];
    $cooler = $_POST['cooler'];
    $psupply = $_POST['psupply'];
    $files = $_FILES['file'];


   			$filename = $files['name'];
   			$fileerror = $files['error'];
   			$filetmp = $files['tmp_name'];

   			$fileext = explode('.', $filename);
   			$filecheck = strtolower(end($fileext));

   			$fileextstore = array('png', 'jpg', 'jpeg');

   			if(in_array($filecheck,$fileextstore)){

   				$destfile = 'upload/'. $filename;
   				move_uploaded_file($filetmp, $destfile);
        
		
	
    $insertquery = "INSERT INTO `custom` (`pc_img`, `pc_name`, `Processor`, `Graphic_card`, `Ram`, `Storage`, `Motherboard`, `Cooler`, `Cabinet`, `Power_Supply`, `pc_Usages`, `Price`, `link`) VALUES ('$destfile', '$lpname', '$processor', '$g_card', '$ram', '$storage', '$motherboard', '$cooler', '$cabinet', '$psupply', '$usage', '$price', '$link');";
	 $query = mysqli_query($conn, $insertquery);

   if($query){
      header("location:update_custom.php");
   }
   else{
     echo "<script>alert('Insertion Fail')</script>";
   }
	 
}
else{
  echo "<script>alert('Img upload fail')</script>";
}
}
?>
  <!-- PHP END -->
  <div class="container mt-4">
    <div class="card shadow-lg p-3 mb-5 bg-white rounded">
      <div class="text-center">
        <h1>
          Custom-build Form
        </h1>
      </div>
      <hr>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">Select image</label>
            <div class="col-sm-10">
              <input type="file" name="file" id="file">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">PC Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="laptopName" name="lpname">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopProccesser">Proccesser</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopProccesser" name="processor">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopRAM">Graphic_card</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopRAM" name="g_card">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Ram</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="ram">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopStorage">Storage</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopStorage" name="storage">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Motherboard</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="motherboard">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Cooler</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="cooler">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Cabinet</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="cabinet">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Power Supply</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="psupply">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopUsage">Usage</label>
            <div class="col-sm-10">
              <select class="form-control" id="LaptopUsage" name="usage">
                <option>Office Work</option>
                <option>Gaming</option>
                <option>Editing</option>
              </select>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopPrice">PC Price</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopPrice" name="price">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopUrl">PC URL</label>
            <div class="col-sm-10">
              <input type="url" class="form-control" id="LaptopUrl" name="link">
            </div>
          </div>
          <hr>
          <div class="text-center">
            <button type="submit" class="btn btn-outline-success" name="submit">Submit</button>
          </div>
        </form>
        

      </div>
    </div>
  </div>
  


  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>

</body>

</html>