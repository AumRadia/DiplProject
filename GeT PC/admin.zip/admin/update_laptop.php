<?php
    session_start();
    
?>
<!DOCTYPE html>
<html>

<head>
  <title>List of Existed Laptop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Kiwi+Maru:wght@300&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  


</head>

<body style="background: rgb(211, 80, 80);
  background: linear-gradient(90deg, rgb(19, 18, 95) 0%, rgb(21, 155, 93) 0%, rgb(70, 172, 192) 100%);">

  <?php 
    include "navbar.php" 
?>



<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Processor</th>
      <th scope="col">Graphic card</th>
      <th scope="col">Details</th>
      <th scope="col">Update</th>
      <th scope="col">Delete</th>


    </tr>
  </thead>
  <tbody>
   
    <?php 
              include "../dbconnect.php";


                $selectquery = "select * from laptop";

                $query = mysqli_query($conn, $selectquery);


                while($res = mysqli_fetch_array($query)){
            ?>
                  <tr>
                    <td><?php echo $res[0] ?></td>
                    <td><?php echo $res[2] ?></td>
                    <td><?php echo $res[3] ?></td>
                    <td><?php echo $res[4] ?></td>
                            
                    <td style="font-size: 20px;"><a href="detail_lap.php?id=<?php echo $res[0] ?>" style="color: black;"><i class="fa fa-eye" ></i></a></td>
                    <td style="font-size: 20px;"><a href="update_lap.php?id=<?php echo $res[0] ?>" style="color: black;"><i class="fa fa-pencil-square-o" ></i></a></td>
                    <td style="font-size: 20px;"><a href="delete_lap.php?id=<?php echo $res[0] ?>" style="color: black;"><i class="fa fa-trash" ></i></a></td>
                    
                  </tr>
              <?php	
                }

            
             ?>



  </tbody>
</table>
  

          
            
         


  <!-- PHP END -->


  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>

</body>

</html>