<?php
    session_start();
    if(!isset($_SESSION['Username'])){
        header("location:index.php");
        
    }
    ?>
<!DOCTYPE html>
<html>

<head>
  <title>Add Laptop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Kiwi+Maru:wght@300&display=swap" rel="stylesheet">


</head>

<body style="background: rgb(211, 80, 80);
  background: linear-gradient(90deg, rgb(19, 18, 95) 0%, rgb(21, 155, 93) 0%, rgb(70, 172, 192) 100%);">
<!-- PHP START -->

  <?php 
    include "navbar.php";    
    include "../dbconnect.php";

    if(isset($_GET['id'])){
        $id = $_GET['id'];
   }
   $update = false;
   $selectquery = "select * from laptop where id = '$id'";

   $query = mysqli_query($conn, $selectquery);
   $res = mysqli_fetch_array($query);

   if(isset($_POST['home'])){       
           header("location:update_laptop.php");       
   }
?>
    
    <!-- PHP END -->
  <div class="container mt-4">
    <div class="card shadow-lg p-3 mb-5 bg-white rounded">
      <div class="text-center">
        <h1>
          Laptop Form
        </h1>
      </div>
      <hr>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">Select image</label>
            <div class="col-sm-10">
             <img src="<?php if(isset($res[1])){echo $res[1];} ?>" height = "200px" width = "200px">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">Laptop Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="laptopName" name="lpname" readonly value="<?php if(isset($res[2])){echo $res[2];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopProccesser">Laptop Proccesser</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopProccesser" name="processor" readonly value="<?php if(isset($res[3])){echo $res[3];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopRAM">Laptop RAM</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopRAM" name="ram" readonly value="<?php if(isset($res[5])){echo $res[5];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopGraphics-Card">Laptop Graphics-Card</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopGraphics-Card" name="g_card" readonly value="<?php if(isset($res[4])){echo $res[4];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopStorage">Laptop Storage</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopStorage" name="storage" readonly value="<?php if(isset($res[6])){echo $res[6];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopUsage">Laptop Usage</label>
            <div class="col-sm-10">
            <input type="text" class="form-control" id="LaptopStorage" name="usages" readonly value="<?php if(isset($res[7])){echo $res[7];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopPrice">Laptop Price</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopPrice" name="price" readonly value="<?php if(isset($res[8])){echo $res[8];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="LaptopUrl">Laptop URL</label>
            <div class="col-sm-10">
              <input type="url" class="form-control" id="LaptopUrl" name="link" readonly value="<?php if(isset($res[9])){echo $res[9];} ?>">
            </div>
          </div>
          <hr>
          <div class="text-center">          
            <button type="submit" class="btn btn-outline-success btn-block" name="home">Back</button>             
          </div>
        </form>
        
      </div>
    </div>
  </div>


  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>

</body>

</html>