<?php
    session_start();
    if(!isset($_SESSION['Username'])){
        header("location:index.php");
        
    }
    ?>
<!DOCTYPE html>
<html>

<head>
  <title>Add Laptop</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Kiwi+Maru:wght@300&display=swap" rel="stylesheet">


</head>

<body style="background: rgb(211, 80, 80);
  background: linear-gradient(90deg, rgb(19, 18, 95) 0%, rgb(21, 155, 93) 0%, rgb(70, 172, 192) 100%);">
  <!-- PHP START -->

  <?php 
    include "navbar.php";    
    include "../dbconnect.php";

    if(isset($_GET['id'])){
        $id = $_GET['id'];
   }
   $selectquery = "select * from custom where id = '$id'";

   $query = mysqli_query($conn, $selectquery);
   $res = mysqli_fetch_array($query);


   if(isset($_POST['update'])){
    $lpname = $_POST['cus_name'];
    $processor = $_POST['processor'];
    $ram = $_POST['ram'];
    $storage = $_POST['storage'];
    $usage = $_POST['usage'];
    $price = $_POST['price'];
    $link = $_POST['link'];
    $g_card = $_POST['g_card'];
    $motherboard = $_POST['motherboard'];
    $cabinet = $_POST['cabinet'];
    $cooler = $_POST['cooler'];
    $psupply = $_POST['p_supply'];
    $files = $_FILES['file'];
  
           $filename = $files['name'];
           $fileerror = $files['error'];
           $filetmp = $files['tmp_name'];
  
           $fileext = explode('.', $filename);
           $filecheck = strtolower(end($fileext));
  
           $fileextstore = array('png', 'jpg', 'jpeg');
  
            if(in_array($filecheck,$fileextstore)){
        
                  $destfile = 'upload/'. $filename;
                  move_uploaded_file($filetmp, $destfile);
                
            
          
          $updatequery = "UPDATE custom SET pc_img = '$destfile', pc_name = '$lpname', Processor = '$processor', Graphic_card = '$g_card', Ram = '$ram', Storage = '$storage', Motherboard = '$motherboard', Cooler = '$cooler', Cabinet = '$cabinet', Power_Supply = '$psupply', pc_Usages = '$usage', Price = '$price', link = '$link' where id = '$id'";
          $query = mysqli_query($conn, $updatequery);

              if ($query) {
                header("location:update_custom.php");
              }
              else{
                echo "<script>alert('Updation Fail')</script>";
              }
          
        }else{
          $updatequery = "UPDATE custom SET pc_name = '$lpname', Processor = '$processor', Graphic_card = '$g_card', Ram = '$ram', Storage = '$storage', Motherboard = '$motherboard', Cooler = '$cooler', Cabinet = '$cabinet', Power_Supply = '$psupply', pc_Usages = '$usage', Price = '$price', link = '$link' where id = '$id'";
          $query = mysqli_query($conn, $updatequery);

              if ($query) {
                header("location:update_custom.php");
              }
              else{
                echo "<script>alert('Updation Fail')</script>";
              }
        }
        
      }  
?>

  <!-- PHP END -->
  <div class="container mt-4">
    <div class="card shadow-lg p-3 mb-5 bg-white rounded">
      <div class="text-center">
        <h1>
          Update Custom builds
        </h1>
      </div>
      <hr>
      <div class="card-body">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">Image</label>
            <div class="col-sm-10">
              <img src="<?php if(isset($res[1])){echo $res[1];} ?>" height="200px" width="200px">
            </div>
            
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="laptopName">Select image</label>
            <div class="col-sm-10">
              <input type="file" name="file" id="file">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="customName">Custom Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="custom_Name" name="cus_name" value="<?php if(isset($res[2])){echo $res[2];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="Proccesser">Proccesser</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="LaptopProccesser" name="processor" value="<?php if(isset($res[3])){echo $res[3];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="RAM">RAM</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="RAM" name="ram" value="<?php if(isset($res[5])){echo $res[5];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="Graphics-Card">Graphics-Card</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Graphics-Card" name="g_card" value="<?php if(isset($res[4])){echo $res[4];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="Storage">Storage</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Storage" name="storage" value="<?php if(isset($res[6])){echo $res[6];} ?>">
            </div>
          
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="motherboard">Motherboard</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Storage" name="motherboard" value="<?php if(isset($res[7])){echo $res[7];} ?>">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="cooler">Cooler</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Storage" name="cooler" value="<?php if(isset($res[8])){echo $res[8];} ?>">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="cabinet">Cabinet</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Storage" name="cabinet" value="<?php if(isset($res[9])){echo $res[9];} ?>">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="p_supply">Power Supply</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Storage" name="p_supply" value="<?php if(isset($res[10])){echo $res[10];} ?>">
            </div>
          </div>

          <div class="form-group row">
                            
                            <label class="col-sm-2 col-form-label">Select Usage</label>
                            <div class="col-sm-10">
                                <select name="usage" class="form-control" >
                                    <option value="<?php if(isset($res[11])){echo $res[11];}?>">Usages : <?php if(isset($res[11])){echo $res[11];}?></option>
                                    <option value="Office work">Office work</option>
                                    <option value="Gaming">Gaming</option>
                                    <option value="Editing">Editing</option>
                                    
                                </select>
                            
                            </div>
                        </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="Price">Custom Price</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" id="Price" name="price" value="<?php if(isset($res[12])){echo $res[12];} ?>">
            </div>
          </div>
          <div class="form-group row">
            <label class="col-sm-2 col-form-label" for="Url">custom URL</label>
            <div class="col-sm-10">
              <input type="url" class="form-control" id="LaptopUrl" name="link" value="<?php if(isset($res[13])){echo $res[13];} ?>">
            </div>
          </div>
          <hr>
          <div class="text-center">
            <button type="submit" class="btn btn-outline-success btn-block" name="update">Update</button>
          </div>
        </form>
        
      </div>
    </div>
  </div>


  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>

</body>

</html>