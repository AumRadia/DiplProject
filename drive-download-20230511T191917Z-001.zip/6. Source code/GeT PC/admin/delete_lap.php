 <!-- PHP START -->

 <?php 
       
    include "../dbconnect.php";

    if(isset($_GET['id'])){
        $id = $_GET['id'];
   }
   $selectquery = "delete from laptop where id = '$id'";

   $query = mysqli_query($conn, $selectquery);

   if($query){
        header("location:update_laptop.php");
   }

?>

 <!-- PHP ENDs -->
