<head>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@700&display=swap" rel="stylesheet">


<style>
nav :hover
{
color: orange;
}

</style>
</head>



<nav class="navbar navbar-expand-lg  " style="background: transparent ; font-family: 'Lato', sans-serif; border: 0px solid black; margin: 15px;"  >
           
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto ">
                    <li class="nav-item active mr-4">
                        <a class="nav-link text-dark " href="index.php"><h4>HOME</h4></a>
                    </li>
                    <li class="nav-item active mr-4">
                        <a class="nav-link text-dark " href="about.php"><h4>ABOUT</h4></a>
                    </li>
                    <li class="nav-item active mr-4">
                        <a class="nav-link text-dark " href="contact.php"><h4>CONTACT</h4></a>
                    </li>
                </ul>
            </div>
</nav>